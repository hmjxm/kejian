package com.mvc.servlet1;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.Info;
import com.mvc.bean.newdao;

public class queservlet extends HttpServlet{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");
		 request.setCharacterEncoding("utf-8");
		 String xh= new String(request.getParameter("xh").getBytes("ISO8859_1"),"utf-8");
		newdao d=new newdao();
		ArrayList<Info> infos=new ArrayList<Info>();
		try {
			infos = d.query(xh);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if(!infos.isEmpty())
		{
	         request.getSession().setAttribute("infos",infos) ;
		     request.getRequestDispatcher("result.jsp").forward(request, response);
		}
		else
    	{
    		request.setAttribute("queError", "无此学号，无法查询，请重新输入！");
	    	request.getRequestDispatcher("query.jsp").forward(request, response);
   	}
	}
}
