package com.mvc.servlet1;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.newdao;

public class delservlet extends HttpServlet{
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 resp.setContentType("text/html");
		 resp.setCharacterEncoding("utf-8");
		 String xh= new String(req.getParameter("xh").getBytes("ISO8859_1"),"utf-8");
		 newdao d=new newdao();
		 try {
			boolean isDelete=d.delete(xh);
			if(isDelete)
			{
				resp.sendRedirect("showServlet");
			}
			else
			{
				req.setAttribute("delError", "不存在此学号，无法删除，请重新输入！");
    	    	req.getRequestDispatcher("delete.jsp").forward(req, resp);     	    	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		 
		 
	}
}
