package com.mvc.bean;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mvc.bean.Info;
import com.mvc.bean.connection;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class dao {
	private Connection conn;
	private PreparedStatement pstat;
	String sql="";
	
	public int logoin(User user) throws SQLException{
	   conn = (Connection) connection.getConnection();
	   sql = "select * from users";	  
	   pstat = (PreparedStatement) conn.prepareStatement(sql);
	   ResultSet rs= (ResultSet) pstat.executeQuery();
	   String uname=user.getUname();
       String pwd=user.getPwd();
       boolean flag=false;
       while(rs.next())
	    {
	            String userName = rs.getString("uname");
	            String userPassword = rs.getString("pwd");
	            if(uname.equals(userName))
	            	flag=true;
	            if((uname.equals(userName))&&(pwd.equals(userPassword))&&pwd.length()>=6)
	            {
	                   return 1;
	            }
	    }	
       if(uname.isEmpty()||pwd.isEmpty())
			return 0;
       if(flag==false)
    	   return 3;
       if(pwd.length()<6)
    	   return 2;     
	    return 4;              
	}
	
	public int regist(User user) throws SQLException{
	   conn = (Connection) connection.getConnection();
	   sql = "insert into users values(?,?)";
	   String sql1="select * from users";	
	    pstat = (PreparedStatement) conn.prepareStatement(sql);
	    pstat.setString(1,user.getUname());
	    pstat.setString(2,user.getPwd());
	    
	    PreparedStatement pstat1=(PreparedStatement) conn.prepareStatement(sql1);
		ResultSet rs= (ResultSet) pstat1.executeQuery();
		if(user.getUname().isEmpty()||user.getPwd().isEmpty())
			return 3;
		boolean flag=false;
	    while(rs.next())
	    {
	    	    String uname=user.getUname();
	            String userName = rs.getString("uname");
	            if((uname.equals(userName)))
	            {
	                   flag=true;
	                   return 0;
	            }
	    }		   
	    if((user.getPwd().toCharArray().length>=6)&&(flag==false))
	    {
	    	pstat.executeUpdate();
	        return 1;
	    }
	    if((user.getPwd().toCharArray().length<6))
	    {
	        return 2;
	    }
	    
	    pstat.close();
	    conn.close();
	    return 4;
	}
	
	
	

	
	public int foget(User user,String pwd2) throws SQLException{   
    	String sql="update users set pwd=? where uname=?";
        conn=(Connection) connection.getConnection(); 
    	pstat=(PreparedStatement) conn.prepareStatement(sql);
    	pstat.setString(1, user.getPwd());
    	pstat.setString(2, user.getUname());
    	
    	String sql1="select * from users";	
    	PreparedStatement pstat1=(PreparedStatement) conn.prepareStatement(sql1);
		ResultSet rs= (ResultSet) pstat1.executeQuery();
		if(user.getUname().isEmpty()||user.getPwd().isEmpty()||pwd2.isEmpty())
			return 0;
		boolean flag=false;
	    while(rs.next())
	    {
	    	    String uname=user.getUname();
	            String userName = rs.getString("uname");
	            if((uname.equals(userName)))
	            {
	                   flag=true;
	            }
	    }	
	    if((user.getPwd().equals(pwd2))&&(user.getPwd().toCharArray().length>=6)&&flag==true)
        {
        		pstat.executeUpdate();
        	    return 1; 
        }  
	    if(flag==false)
	    	return 2;
	    if(user.getPwd().length()<6||pwd2.length()<6)
        	return 3;
	    if(!user.getPwd().equals(pwd2))
	    	return 4;
	    
        return 5;
  	}
	
	
	
	 public boolean zx(String uname) throws SQLException{   
	        sql="DELETE FROM users WHERE uname=? "; 
	        conn=(Connection) connection.getConnection(); 
	    	pstat=(PreparedStatement) conn.prepareStatement(sql);
	    	pstat.setString(1, uname);
	    	if(pstat.executeUpdate()==1)
	    	{
	    		return true;
	    	}  	
	    	return false;    	 
	  	}
	 
	 
		
		
	
}
