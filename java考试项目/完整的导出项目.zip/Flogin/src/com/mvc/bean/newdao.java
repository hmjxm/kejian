package com.mvc.bean;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mvc.bean.Info;
import com.mvc.bean.connection;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class newdao {
	private Connection conn;
	private PreparedStatement pstat;
	String sql="";
	
	public ArrayList<Info> show(){ 
    	ArrayList<Info> infos=new ArrayList<Info>();
 	   try {	
 		  
 	       conn = (Connection) connection.getConnection();
 	 	   sql = "select * from xs"; 
 	 	   pstat = (PreparedStatement) conn.prepareStatement(sql);
		   ResultSet rs= (ResultSet) pstat.executeQuery();
		   while(rs.next())
		    {
		            String xh= rs.getString(1);
		            String xm = rs.getString(2);
		            int age = rs.getInt(3);
		            String xy = rs.getString(4);
		            Info info=new Info(xh,xm,age,xy);
		            infos.add(info);
		    }
	} catch (SQLException e) {
		e.printStackTrace();
	}
 	   return infos;
    }
	
	
	public void insert(Info info){
	 	   conn = (Connection) connection.getConnection();
	 	   sql = "insert into xs values(?,?,?,?)";
	 	   try{
	 	    pstat = (PreparedStatement) conn.prepareStatement(sql);
	 	    pstat.setString(1,info.getXh());
	 	    pstat.setString(2,info.getXm());
	 	    pstat.setInt(3, info.getAge());
	 	    pstat.setString(4,info.getXy());
	 	    pstat.executeUpdate();
	 	    pstat.close();
	 	    conn.close();
	 	   
	 	   }catch(SQLException e){
	 	    e.printStackTrace();
	 	   }
	 	  
	 	}
	
	
	 public boolean delete(String xh) throws SQLException{   
	        sql="DELETE FROM xs WHERE xh=?"; 
	        conn=(Connection) connection.getConnection(); 
	    	pstat=(PreparedStatement) conn.prepareStatement(sql);
	    	pstat.setString(1, xh);
	    	if(pstat.executeUpdate()==1)
	    	{
	    		return true;
	    	}  	
	    	return false;    	 
	  	}
	 
	 public boolean update(Info info) throws SQLException{   
	    	String sql="update xs set xm=?, age=?,xy=? where xh=?";
	        conn=(Connection) connection.getConnection(); 
	    	pstat=(PreparedStatement) conn.prepareStatement(sql);
	    	pstat.setString(1, info.getXm());
	    	pstat.setInt(2, info.getAge());
	    	pstat.setString(3, info.getXy());
	    	pstat.setString(4, info.getXh());
	    	if(pstat.executeUpdate()==1)
	    	{
	    		return true;
	    	}  	
	    	return false;    	 
	  	}
	 
	 public ArrayList<Info> query(String xh) throws SQLException{
	    	ArrayList<Info> infos=new ArrayList<Info>();
	 	   conn = (Connection) connection.getConnection();
	 	   sql = "select * from xs  where xh=?";  
	 	   pstat = (PreparedStatement) conn.prepareStatement(sql);
	 	   pstat.setString(1, xh);
	 	   ResultSet rs= (ResultSet) pstat.executeQuery();
	 	   while(rs.next())
	 	   {
	 		  String xm = rs.getString(2);
	          int age = rs.getInt(3);
	          String xy = rs.getString(4);
	          Info info=new Info(xh,xm,age,xy);
	          infos.add(info);
	 	   }
	 	   return infos;
	 	}
}
