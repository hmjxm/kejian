package com.mvc.bean;

public class Info {
	private String xh;
	private String xm;
	private String xy;
	private int age;
	
	public Info(String xh,String xm,int age,String xy){
		this.xh=xh;
		this.xm=xm;
		this.age=age;
		this.xy=xy;
	}
	
	public void setXm(String xm){
		this.xm=xm;
	}
	public String getXm(){
		return this.xm;
	}
	
	public void setXh(String xh){
		this.xh=xh;
	}
	public String getXh(){
		return this.xh;
	}
	
	public void setAge(int age){
		this.age=age;
	}
	public int getAge(){
		return  age;
	}
	
	public void setXy(String xy){
		this.xy=xy;
	}
	public String getXy(){
		return this.xy;
	}

}

