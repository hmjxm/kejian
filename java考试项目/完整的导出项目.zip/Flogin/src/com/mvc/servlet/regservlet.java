package com.mvc.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.User;
import com.mvc.bean.dao;

public class regservlet extends HttpServlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 resp.setContentType("text/html");
		 resp.setCharacterEncoding("utf-8");
		 String runame = new String(req.getParameter("runame").getBytes("ISO8859_1"),"utf-8");
		 String rpwd= new String(req.getParameter("rpwd").getBytes("ISO8859_1"),"utf-8");
		User user=new User(runame,rpwd);
		dao d=new dao();
		int isReg;
		try {
			isReg = d.regist(user);
			switch(isReg)
			{
			case 0:{req.setAttribute("regError", "此用户名已存在,请重新输入!");
	                req.getRequestDispatcher("reg.jsp").forward(req, resp);
			        break;
			        }
			case 1:resp.sendRedirect("login.jsp");break;
			case 2:{req.setAttribute("regError", "密码位数不得少于6位,请重新输入!");
                    req.getRequestDispatcher("reg.jsp").forward(req, resp);
	                break;
	               }
			case 3:{req.setAttribute("regError", "用户名或密码不能为空,请重新输入!");
                    req.getRequestDispatcher("reg.jsp").forward(req, resp);
                    break;
                   }
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
}
