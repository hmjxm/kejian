package com.mvc.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.User;
import com.mvc.bean.dao;

public class zxservlet extends HttpServlet{
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 resp.setContentType("text/html");
		 resp.setCharacterEncoding("utf-8");
		 String uname = new String(req.getParameter("uname").getBytes("ISO8859_1"),"utf-8");
		 dao d=new dao();
		 try {
			boolean iszx=d.zx(uname);
			if(iszx)
			{
				resp.sendRedirect("login.jsp");
			}
			else
			{
				req.setAttribute("zxError","此用户名不存在，无法注销，请重新输入！");
    	    	req.getRequestDispatcher("zx.jsp").forward(req, resp);     	    	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		 
		 
	}
}
