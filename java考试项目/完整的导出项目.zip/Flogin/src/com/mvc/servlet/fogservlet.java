package com.mvc.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.User;
import com.mvc.bean.dao;

public class fogservlet extends HttpServlet{
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 resp.setContentType("text/html");
		 resp.setCharacterEncoding("utf-8");
		 String funame = new String(req.getParameter("funame").getBytes("ISO8859_1"),"utf-8");
		 String pwd1= new String(req.getParameter("pwd1").getBytes("ISO8859_1"),"utf-8");
		 String pwd2= new String(req.getParameter("pwd2").getBytes("ISO8859_1"),"utf-8");	
		 User user=new User(funame,pwd1);
		 dao d=new dao();
		 try {
			 int isForget=d.foget(user,pwd2);
			 switch(isForget)
			 {
			 case 0:{
				     req.setAttribute("fogError", "用户名或密码不得为空，请重新输入！");
	    	         req.getRequestDispatcher("fog.jsp").forward(req, resp);
	    	         break;
			        }
			 case 1:{
				     resp.sendRedirect("login.jsp");
				     break;
			        }
			 case 2:{
			         req.setAttribute("fogError", "此用户名不存在，无法重置密码，请重新输入！");
    	             req.getRequestDispatcher("fog.jsp").forward(req, resp);
    	             break;
		            }
			 case 3:{
		             req.setAttribute("fogError", "密码不得少于6位，请重新输入！");
	                 req.getRequestDispatcher("fog.jsp").forward(req, resp);
	                 break;
	                }
			 case 4:{
	                 req.setAttribute("fogError", "两次密码输入不一致，请重新输入！");
                     req.getRequestDispatcher("fog.jsp").forward(req, resp);
                     break;
                    }
			 }
		 } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}
