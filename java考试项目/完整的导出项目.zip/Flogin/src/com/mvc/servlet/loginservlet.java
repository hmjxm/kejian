package com.mvc.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.User;
import com.mvc.bean.dao;

public class loginservlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");
		 request.setCharacterEncoding("utf-8");
		String uname =request.getParameter("uname");
		 String pwd= request.getParameter("pwd");
		User user=new User(uname,pwd);
		dao d=new dao();
		int isLogin;
		try{
		 	isLogin=d.logoin(user);
		 	switch(isLogin)
		 	{
		 	case 0:{request.setAttribute("loginError", "用户名或密码不能为空,请重新输入!");
	                request.getRequestDispatcher("login.jsp").forward(request, response);
		 	        break;
		 	       }
		 	case 1:{
		   		    request.getSession().setAttribute("user", user);
	 		        response.sendRedirect("showServlet");
	 		        break;
		           }
		 	case 2:{request.setAttribute("loginError", "密码位数不得少于6位,请重新输入!");
		 	        request.getRequestDispatcher("login.jsp").forward(request, response);
 	                break;
 	               }
		 	case 3:{request.setAttribute("loginError", "此用户名不存在,请重新输入!");
 	                request.getRequestDispatcher("login.jsp").forward(request, response);
                    break;
                   }
		 	}
		   }catch(SQLException e){
		        e.printStackTrace();
		 }
}
}
